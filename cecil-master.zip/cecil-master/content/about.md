---
title: About
menu:
  main:
    weight: 1001
published: true
---

> Cecil is a ready to use static blog, powered by [Hyde](https://github.com/PHPoole/PHPoole-theme-hyde), [PHPoole](http://phpoole.org) and [Netlify](https://www.netlify.com).

## How to use?

### Setup your blog

Use the following button to configure and deploy your new blog on Netlify.

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/PHPoole/Cecil)
